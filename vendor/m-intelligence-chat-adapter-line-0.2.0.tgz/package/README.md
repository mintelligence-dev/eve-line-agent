# @m-intelligence/chat-adapter-line

> npm package: [`@m-intelligence/chat-adapter-line`](https://www.npmjs.com/package/@m-intelligence/chat-adapter-line) (not published yet)

LINE adapter for [Chat SDK](https://chat-sdk.dev), built on the [LINE Messaging API](https://developers.line.biz/en/docs/messaging-api/). It follows the layout and conventions of the official `@chat-adapter/*` packages and has no dependency on `@line/bot-sdk`.

Documentation: [chat-sdk.dev/adapters](https://chat-sdk.dev/adapters) · Guides: [vercel.com/kb/chat-sdk](https://vercel.com/kb/chat-sdk)

## Installation

```bash
npm i @m-intelligence/chat-adapter-line chat
```

## Usage

```typescript
import { Chat } from "chat";
import { createRedisState } from "@chat-adapter/state-redis";
import { createLineAdapter } from "@m-intelligence/chat-adapter-line";

export const bot = new Chat({
  userName: "mybot",
  adapters: {
    line: createLineAdapter(),
  },
  // Reply tokens, quote tokens, and dedupe markers live here — use a shared
  // store in production so they survive serverless cold starts.
  state: createRedisState({ url: process.env.REDIS_URL }),
});

bot.onDirectMessage(async (thread, message) => {
  await thread.startTyping();
  await thread.post({ markdown: `Hi ${message.author.fullName}!` });
});
```

`createLineAdapter()` reads `LINE_CHANNEL_ACCESS_TOKEN` and `LINE_CHANNEL_SECRET` from the environment when no config is passed.

### Webhook route

LINE only sends `POST` requests — there is no verification handshake to answer.

```typescript title="app/api/webhooks/line/route.ts"
import { after } from "next/server";
import { bot } from "@/lib/bot";

export async function POST(request: Request): Promise<Response> {
  return bot.webhooks.line(request, {
    waitUntil: (task) => after(() => task),
  });
}
```

Point the webhook URL in the [LINE Developers Console](https://developers.line.biz/console/) at `https://your-domain.com/api/webhooks/line` and turn on **Use webhook**.

## Configuration

| Option | Env fallback | Description |
| --- | --- | --- |
| `channelAccessToken` | `LINE_CHANNEL_ACCESS_TOKEN` | Channel access token, used as the API bearer token. |
| `getChannelAccessToken` | — | Async token provider for rotating or short-lived tokens. Wins over `channelAccessToken`. |
| `channelSecret` | `LINE_CHANNEL_SECRET` | Channel secret, used to verify `x-line-signature`. Must not be blank. |
| `botUserId` | `LINE_BOT_USER_ID` | The bot's user ID. Fetched from `/v2/bot/info` at startup when omitted. |
| `userName` | `LINE_BOT_USERNAME` | Bot display name used by Chat SDK. Defaults to `line-bot`. |
| `markdownRendering` | — | `auto` (default), `flex`, or `text`. See [Rich Markdown](#rich-markdown). |
| `uploadFile` | — | Hosts outbound binaries so `files` can be sent. See [Media](#media). |
| `resolveProfiles` | — | Look up author display names (cached in state). Defaults to `true`. |
| `respondToAllMentions` | — | Treat `@All` in a group as a mention of the bot. Defaults to `false`. |
| `loadingSeconds` | — | Loading-indicator duration per request, 5–60. Defaults to `20`. |
| `sender` | — | Default `{ name, iconUrl }` shown on every outbound message. |
| `notificationDisabled` | — | Send pushes silently. Defaults to `false`. |
| `pushRetries` | — | Retries for pushes that hit a 5xx or network error. Defaults to `2`. |
| `replyTokenTtlMs` | — | How long a reply token stays usable. Defaults to `55000`. |
| `eventDedupeTtlMs` | — | How long processed webhook event IDs are remembered. Defaults to 24 h. |
| `requestTimeoutMs` | — | Deadline for each Messaging API request. Defaults to 10 s, well inside a reply token's ~1-minute life. |
| `maxDownloadBytes` | — | Largest inbound download (content, previews, LIFF files). Defaults to 100 MiB; files LINE reports as larger are refused before any request. |
| `downloadTimeoutMs` | — | Deadline for one content download. Defaults to 120 s. |
| `apiUrl` / `blobApiUrl` | — | Messaging / data API base URLs, for proxies and tests. |
| `logger` | — | Custom Chat SDK logger. |

## How delivery works

LINE has two ways to send a message, and they are not equivalent:

- **Reply** (`/v2/bot/message/reply`) uses the `replyToken` that arrives with an inbound event. It is single-use, valid for about a minute, and does **not** count against the message quota.
- **Push** (`/v2/bot/message/push`) can be sent at any time and **is** metered.

Handlers post asynchronously, often in a different serverless invocation from the webhook that triggered them, so the adapter stores each thread's reply token in the **Chat SDK state adapter** and claims it atomically before use, so two instances can never spend the same token. `postMessage` replies when a token is available and pushes otherwise.

Pushes are idempotent: every push carries an `X-Line-Retry-Key`, a 5xx or network failure is retried with the same key, and LINE's `409` (already accepted) counts as success — a retry never delivers twice. A reply that fails ambiguously is not re-sent as a push either, for the same reason.

When your own code may run the same send twice — a retried workflow step or queue job — pass a stable key so LINE delivers it once:

```typescript
await line.sendLineMessages(threadId, messages, { retryKey: stepUuid });
```

## Events

Every LINE webhook event type is understood. Where Chat SDK has a matching hook, the event goes there; everything is also available through `onLineEvent`.

| LINE event | Chat SDK |
| --- | --- |
| `message` | `onDirectMessage`, `onNewMention`, `onSubscribedMessage`, … |
| `messageEdited` (groups) | `onMessageUpdated` — out-of-order edits are dropped, newest wins |
| `unsend` | `onMessageDeleted` |
| `postback` | `onAction` |
| `follow`, `join` | `onInstalled` |
| `unfollow`, `leave` | `onUninstalled` |
| `memberJoined` | `onMemberJoinedChannel` (one call per member) |
| everything else | `adapter.onLineEvent(type, handler)` |

A Chat SDK runtime older than 4.41 has no `onMessageUpdated`, `onMessageDeleted`, `onInstalled` or `onUninstalled`. eve 0.49, for example, bundles Chat SDK 4.34. The adapter then skips those hooks rather than failing the webhook, and the events still reach `onLineEvent`.

```typescript
const line = bot.getAdapter("line");

line.onLineEvent("beacon", async (event, { threadId }) => {
  if (event.beacon.type === "enter" && threadId) {
    await bot.thread(threadId).post("Welcome to the store!");
  }
});
```

Redeliveries are deduplicated by `webhookEventId`: an event LINE re-sends because the first attempt never ran is processed, while one that already ran is dropped — including postbacks, which Chat SDK itself does not dedupe. If an event cannot be handed off because the state adapter is down, the webhook answers `503` after the rest of the batch, so LINE redelivers it when [webhook redelivery](https://developers.line.biz/en/docs/messaging-api/receiving-messages/#webhook-redelivery) is on; storing reply and quote tokens is best effort and never costs the message itself. Standby-mode events (another channel holds chat control) reach `onLineEvent` but never Chat SDK, and the console's verify probe is ignored.

## Typed inbound data

Inbound messages are `LineMessage` instances. Their getters read LINE-native data from the raw event: `mentions`, `mentionsBot`, `mentionsAll`, `emojis`, `sticker`, `location`, `media`, `quoteToken`, `quotedMessageId`, and `markAsReadToken`.

```typescript
import { getLineMessageData, isLineMessage } from "@m-intelligence/chat-adapter-line";

bot.onNewMention(async (thread, message) => {
  if (isLineMessage(message) && message.sticker) {
    await thread.post(`Nice sticker (${message.sticker.keywords?.join(", ")})`);
  }
});
```

Queues, workflows, and Chat SDK's `reviver` hand back a plain `Message`, so use `getLineMessageData(message)` there — it reads the same data from `message.raw`. Messages read back from thread history carry no raw payload (Chat SDK drops it), so it returns `null` for those.

## Native LINE messages

Post stickers, locations, images, imagemaps, templates, or hand-built Flex through a portable `PostableObject`: on LINE it sends the native messages, on any other adapter it posts the fallback text.

```typescript
import { linePostable, lineLocation, lineSticker } from "@m-intelligence/chat-adapter-line";

await thread.post(
  linePostable(
    [lineSticker("446", "1988"), lineLocation({ title: "Office", address: "Bangkok", latitude: 13.75, longitude: 100.5 })],
    { fallbackText: "See you at the office!" }
  )
);
```

Mentions and LINE emoji use text message v2:

```typescript
import { lineText, linePostable } from "@m-intelligence/chat-adapter-line";

await thread.post(
  linePostable(lineText("@Somchai please check", { mentions: [{ index: 0, length: 8, userId: "U4af4…" }] }))
);
```

Builders validate LINE's documented limits before anything is sent, and name the offending property when they fail. Object literals in the shape other LINE adapters accept (`{ sticker }`, `{ location }`, `{ flex }`, `{ image }`, …) are understood by `adapter.postMessage()` only. Through `thread.post()`, build the message with a builder and wrap it — `thread.post(linePostable(lineSticker("446", "1988")))` — because Chat SDK's `thread.post()` only accepts its own postable shapes and throws after sending anything else (`{ raw, quoteToken }` is fine). `adapter.sendLineMessages()` and `linePostable()` take LINE message objects, as the builders return them.

## Rich Markdown

LINE text has no formatting. With `markdownRendering: "auto"` (the default), casual replies stay plain text, while Markdown that carries **tables, code blocks, or several headings** — typical AI answers — renders as Flex bubbles: real table grids, shaded code blocks, bold headings, bulleted lists, and tappable links. `altText` (notifications, chat list) is the plain-text rendering.

Flex bubbles cannot be long-pressed to copy like a text message; set `markdownRendering: "text"` when users need to copy code or numbers from answers.

Plain text is split at LINE's 5,000-character limit on paragraph, line, sentence, or word boundaries — including Thai, which has no spaces between words — and never inside an emoji.

## Cards and buttons

A Chat SDK card becomes one Flex bubble: `imageUrl` is the hero, `title` and `subtitle` head the body, fields render as two-column rows, tables as grids, and buttons land in the footer. Buttons past the fourth, plus every select and radio option, ride along as quick replies.

LINE caps postback `data` at 300 characters. Payloads that fit travel inline; longer ones are parked in the state adapter for 7 days (the lifetime Chat SDK gives its own callback tokens) and referenced by a short key, so a click always resolves to the original action ID and value. Postbacks the adapter did not create — rich menus, LIFF — pass through with the raw string as the action ID.

## Media

Inbound image, video, audio, and file messages arrive as lazy attachments. `fetchData()` waits for LINE to finish transcoding video and audio, and `fetchMetadata` lets `rehydrateAttachment` rebuild the download after a message is serialized for a queue or workflow.

LINE has no upload endpoint — media messages carry HTTPS URLs. Attachments that already have a URL are sent directly. For binary `files`, pass `uploadFile`:

```typescript
import { put } from "@vercel/blob";

createLineAdapter({
  uploadFile: async (file) => {
    const blob = await put(file.filename, file.data, { access: "public" });
    return blob.url;
  },
});
```

## Platform features

| Capability | API |
| --- | --- |
| Quote reply | `thread.reply(message, …)` / `adapter.reply(threadId, messageId, …)` |
| Read receipts | `thread.markAsRead()` / `adapter.markAsRead(threadId, messageId)` |
| Typing | `thread.startTyping()` — the loading animation is refreshed until the reply is sent |
| Users | `adapter.getUser(userId)`, `adapter.openDM(userId)` |
| Conversations | `adapter.fetchThread()`, `adapter.fetchChannelInfo()` (group name, member count), `adapter.leaveChat(threadId)` |
| Broadcast | `adapter.broadcast()`, `adapter.multicast()` (auto-chunked past 500 users), `adapter.narrowcast()` + `getNarrowcastProgress()` |
| Rich menus | `adapter.linkRichMenu()`, `unlinkRichMenu()`, `getUserRichMenuId()`, bulk link/unlink, default rich menu |
| Account link | `adapter.issueLinkToken(userId)` |
| Quota | `adapter.getMessageQuota()` |
| Validation | `adapter.validateMessages(kind, messages)` — LINE's own validator, no message sent |
| Quick replies on answers | `adapter.renderLineMessages(postable)` returns what `postMessage` would send; add chips with `withQuickReplies()` and send with `adapter.sendLineMessages()` |
| Anything else | `adapter.callApi(path, init)` — any Messaging API endpoint with the adapter's credentials, timeouts, and error mapping; `rawBody` sends binary uploads such as rich menu images |
| Followers | `for await (const id of adapter.followerIds())` |

## Thread IDs

```text
line:{botUserId}:{sourceType}:{sourceId}
```

`botUserId` is the webhook's `destination`, so threads of different LINE channels never collide. Chat SDK routes every `line:` thread to the adapter registered as `line`, so run one `Chat` instance per LINE channel; a thread of another channel is refused instead of being sent with the wrong credentials. `sourceType` is `user`, `group`, or `room`; `isDM()` is true only for `user`.

## Errors

LINE failures throw `LineApiError` with a shared `AdapterError` code and LINE's request ID. A `429` throws `LineRateLimitError`, which extends Chat SDK's `AdapterRateLimitError`, so cross-adapter `instanceof AdapterRateLimitError` checks work and `retryAfter` is set when LINE sends `Retry-After`.

## Platform limits

| Capability | Status |
| --- | --- |
| Unsend | Reaches `onMessageDeleted` and drops the message's stored tokens. Chat SDK's persisted thread history has no delete API, so the unsent text stays there until the history TTL; purge your own stores in the handler |
| Edit / delete bot messages, reactions | Not supported by LINE — the adapter throws `NotImplementedError`, Chat SDK's error for unsupported features |
| Message history | Not exposed by LINE; the SDK persists history (`persistThreadHistory`) |
| Typing indicator | 1:1 chats only |
| Streaming | Buffered — LINE cannot edit messages, so the reply is sent once |

## Development

```bash
npm install
npm test          # vitest, incl. Chat SDK contract tests, a real-Chat integration suite, and a replay pass over every fixture
npm run check     # Ultracite (Biome) lint + format, the same setup as vercel/chat
npm run typecheck
npm run build
```

Webhook fixtures live in [`fixtures/webhooks/`](fixtures/webhooks) and are documented in [`sample-messages.md`](sample-messages.md).

## License

MIT
